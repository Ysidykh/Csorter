NAME
		
				sorter.c -- sorts CSV files
				
SYNOPSIS

	A continuation of project0, this new program maintains the same functionality,
	and extends it depending on what parameters are passed into it.

	
USAGE
	SINGLE CSV FILE:
	cat [input_file.csv] | /a.out -c  [SORTING COLUMN]
	
	Takes a csv file that's piped into STNDIN as input, and outputs every row
	sorted according to the SORTING COLUMN which must match exactly with one of
	the 'header' strings stored in the first row of the CSV to STNDOUT.
	
	MULTIPLE CSV FILES:
	/a.out -c  [SORTING COLUMN] -d [INPUT DIRECTORY] -o [OUTPUT DIRECTORY]
	
	Finds all CSV files with the same amount of columns in the INPUT DIRECTORY	
	and all of its children, and starts a new process that parses, sorts, and
	outputs every file found as a new CSV into the OUTPUT DIRECTORY.
	
DATA STRUCTURE
	Either from a file or from STNDIN, each CSV file is read line by line into a
	buffer string.  Each string is put into a ROW element as is.  Each of the
	rows is then put into a scalable array of row pointers.  This is the basic
	structure.
	From there, each comma in the CSV file that seperates the individual data 
	fields is replaced with a end of line character.  This new internal row 
	buffer is passed through character by character, and each time an EOL char
	is found, a pointer is created and stored at that location in a new Col
	structure.  These pointers are stored in a scalable array of Col pointers.
	So internally, there is a growable pointer array that points to each row,
	and inside of each row, there is an array of pointers that points to each
	data field.
	This is a completely generic structure, and will function for CSV files of
	any size and any length, assuming that the length of each individual line
	of the original input does not exceed the char limit of the initial 
	read-in buffer (2047 chars).  Which should be plenty.  Should be.
	
SORTING ALGORITHM
	The sorting algorithm is mergesort, but the implementation is slightly different given multiple files as input.  Instead of forking off and checking each file, each file found is checked to be a csv, in the parent or each dir_read child.  All of those csv file paths are stored in a FileName array, and the process_stream() function iterates through it, creating a child for each, sorting, and outputting them.

	
FORKING
	If the program finds 7 argv parameters, it will iterate itself through 
	the specificed INPUT DIRECTORY and find all CSV files that share the same
	header length (# of sortable columns) that also contains the SORTING COLUMN.
	Each file will be sorted individually and output into a new CSV file named
	[INPUTFILE]-sorted-[SORTING COLUMN].csv.
	These new files will not be printed, but when the program ends, it will print:
	
	Initial PID: XXXXX
	PIDS of all child processes: AAA,BBB,CCC,DDD,EEE,FFF, etc
	Total number of processes: ZZZZZ
	Have nice day.
	
TESTING PROCEDURE
	The most difficult part of this assignment was parsing a string into a scalable,
	lossless, discrete, and completely generic data structure that can hold
	CSV files of any size and length, and also be easy to sort through.
	Many things were tested for parsing: empty data fields, multiple commas, 
	commas at the end of every input line, escape characters within data fields, 
	different languages (cyrillic characters)...  We attempted to account for 
	every possible form of data corruption and grader trickyness.
	
	The crux of the entire parsing function is the first line of the CSV, which 
	is referred to as the HEAD.  It was also tested extensively for quotes, extra commas,
	case sensitivity, and null strings.  The head is what determines if a CSV is 
	"compatible" in the multiple directory sort.  The first line of every CSV found is
	stored in a row_array.  The program iterates through every head, dumps the files that
	don't contain the SORTING COLUMN, and forks a new sort for each one, with the added
	output file generated.

DIRECTORY TRAVERSAL

This was one of the trickiest parts of the program to implement.  A custom strcat method was written to insert the backslashes needed to traverse a directory structure recursively.  The function dir_read() traverses through a directory using readdir(), and when it found a file, it confirmed that it was a .csv by checking the last 4 characters of the d_name string in the dirent structure returned by readdir(), and shoved that file�s absolute path into a FileName structure.  This structure contains the directory path and the filename in two separate buffers.  Originally, one buffer was going to be used for both, flushed and reallocated between readdir() calls, but that kept segfaulting, so we took the easy way out.

If the dir_read() function found a directory (that wasn�t the output dir or . or ..), a new process was called which performed the above functions.  Instead of also sorting and outputting the csv files within a child process though, these dir_read children are culled at the end of the read_dir function, and the entire FileName array of all the csv files found in the entire directory structure continues to the process_stream() function.

PROCESS_STREAM

The process_stream() function opens each csv file found in a new process, takes the head out, verifies that the sorting column is present, and if it is, sorts it and plops it into the output directory.  The final output is also written here.  When each sorting child exits, that process ID is printed out to the list of all processes, and the total number of processes is increased.

Final Output:
The first line of the final output is written before anything happens in main().  It�s just the PID of the parent process.  After that, a line is printed:
�PIDs of all children: �

This line does not have a newline because each dir_read() and process_file() child prints its PID on that line (after flushing the inherited stdout buffer).

After that, the total number of created process (tracked with a static variable inside of a mutex) is printed, showing the total number of processes created (excluding the parent).


