#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include"sorter.h"

/*
 Compares two strings.
Compares X to Y.
If X is less than or equal to Y, then the function returns 1. Otherwise it returns 0.
This function expects X and Y to be in the context of the Latin Script; the only input that would be valid is anything that belongs to the Latin Script in the unicode set.
 */
 int isLatinScript( short C)
{
  return (C>=32 && C<=126);
}    
///////////////////////// COLUMNS /////////////////////////////////


Cols *cols_create() { //allocate memory for the array of columns (empty initially)
	Cols *c = (Cols*)malloc(sizeof(Cols));
	c->length = 0; //length of zero
	c->arr = NULL; //points to nothing
	return c;
}
int cols_append(Cols *cols, char *c) {
	cols->arr = realloc(cols->arr, sizeof(char*)*(cols->length + 1)); //grows the array arr to accomodate a new pointer to a column
	cols->arr[cols->length] = c; //populates the newly allocated element within the array
	cols->length++;
	return cols->length; //TODO: returns an int for error handing (improper memory allocation)
}

void cols_print(Cols* cols) { //prints columns arr
	int i;
	for(i = 0; i < cols->length; i++){
		printf("column %d: %s\n",i,cols->arr[i]);
	}

}

void cols_populate(Cols *cols, char *buf) {
	char *p = buf; //points to start of buf
	char *col = buf; //initial column pointer
	int in_quote = 0; //custom boolean value
	while(*p) {
		if(*p == '"') {
			in_quote = 1 - in_quote; //toggle value of in_quote
		}
		if(*p == ',' && !in_quote) {
			*p = 0x00; //replaces comma with end of line char (0)
			cols_append(cols, col); //append to the cols array
			col = p + 1; //reposition col to point to next char after 0
		}

		p++;
	}
	cols_append(cols, col); //append to the cols array (for the final column)
}

void cols_destroy(Cols *cols) { //frees allocated col_arr memory
	free(cols->arr); //frees the memory allocated for the array arr
	free(cols);//frees the pointer to the array structure
}

///////////////////////////////// ROW STRUCTURE /////////////////////////


Row *row_create(char *buffer) {
	//allocate memory for the row structure
	Row *r = (Row*)malloc(sizeof(Row));
	//allocate memory for the row's buf
	r->buf = (char*)malloc(strlen(buffer) + 1); //length + null byte
	//copy data from buffer into buf
	strcpy(r->buf, buffer);  //copy buffered chars into row's buf
	int l = strlen(r->buf); //removes end of line character
	if(r->buf[l-1] == 0x0a) { //checks CRLF (windows and Linux)
		//if(r->buf[strlen(r->buf)-1] == '\n') THIS ALSO WORKS
		r->buf[l-1] = 0;
	}
	if(r->buf[l-2] == 0x0d) { //checks CRLF (windows only)
		//if(r->buf[strlen(r->buf)-1] == '\r') THIS ALSO WORKS
		r->buf[l-2] = 0;
	}

	r->cols = cols_create();
	cols_populate(r->cols, r->buf);

	return r;
}
void row_destroy(Row* row) { //frees memory, contents first, and then structure
	cols_destroy(row->cols);
	free(row->buf);
	free(row);
}

void row_print(Row* row) { //prints out the contents of the row
	printf("Row has %d columns\n", row->cols->length);
	cols_print(row->cols);
	//printf("---- row ---- buf: >>[%s]<<\n", row->buf);DEBUG
}

int row_find_column(Row *row, const char *str_to_find) { //returns index of str_to_find OR -1 if not found
	int i;
	for(i = 0; i < row->cols->length; i++) {
		if(strcmp(row->cols->arr[i],str_to_find) == 0) {
			return i;
		}
	}
	return -1;
}



/////////////////////APPENDABLE ARRAY OF ROWS //////////////////////



Rows *rows_create() { //allocate memory for the array of rows (empty initially)
	Rows * r = (Rows*)malloc(sizeof(Rows));
	r->length = 0; //length of zero
	r->arr = NULL; //points to nothing
	return r;
}

void rows_destroy(Rows* rows) { //frees memory of rows array
	//frees the memory that the Rows in the array point to
	int i = 0;
	while(i < rows->length) { //does nothing if length is zero (empty)
		row_destroy(rows->arr[i++]);
	}
	free(rows->arr); //frees the memory allocated for the array arr
	//frees the pointer to the array structure
	free(rows);
}

int rows_append(Rows* rows, Row* row) { //adds a row to the array and returns the new length of the array arr
	rows->arr = realloc(rows->arr, sizeof(*row)*(rows->length + 1)); //grows the array arr to accomodate a new pointer to a row
	rows->arr[rows->length] = row; //populates the newly allocated element with the row in the parameter
	rows->length++;
	return rows->length; //TODO: returns an int for error handing (improper memory allocation)
}

void rows_print(Rows* rows) { //prints entire rows structure (debug)

	printf("length of rows array: %d\n", rows->length);
	int i;
	for(i = 0; i < rows->length; i++) {
		printf("row %d: ",i+1);
		row_print(rows->arr[i]);
	}
}
void rows_print_csv(Rows *rows, Row *head, FILE *out) { //final formatted output
	int i;
	//print header line
	for(i = 0; i < head->cols->length; i++){
			fprintf(out, "%s",head->cols->arr[i]);
			if (i < head->cols->length - 1){
				fprintf(out, ",");
			}

		}
	fprintf(out, "\n");

	for (i = 0; i < rows->length; i++) {
		int j;
		for(j = 0; j < rows->arr[i]->cols->length; j++) {
			fprintf(out, "%s",rows->arr[i]->cols->arr[j]);
			if (j < rows->arr[i]->cols->length - 1){
				fprintf(out, ",");
			}
		}
		fprintf(out, "\n");
	}

}

int Compare(char *X, char *Y)
{
  int Comparison = 1;
  float str1Num;
  float str2Num;
  int i = 0;
  int j = 0;
  char str1[strlen(X)+1];
  char str2[strlen(Y)+1];
  for(i = 0;i<strlen(X);i++)
    {
      if(isLatinScript(X[i])&& isalnum(X[i]))
	{
	  str1[j] = X[i];
	  j++;
	}
    }
  j = 0;
  for(i =0; i<strlen(Y);i++)
    {
      if(isLatinScript(Y[i]) && isalnum(Y[i]))
	{
	  str2[j] = Y[i];
	  j++;
	}
    }
  if( ( (isdigit(str1[0]) && (isdigit(str1[strlen(str1)-1])))) &&( (isdigit(str2[0])) && (isdigit(str2[strlen(str2) - 1]))) )
    {
      str1Num = strtof( str1, NULL);
      str2Num = strtof(str2, NULL);
      if(str1Num>str2Num)
	{
	  Comparison = 0;
	  //printf("%.1f is greater than %.1f\n", str1Num, str2Num);
	}
    }
  else
    {

	       int temp =  strcmp(str1, str2);
	       if(temp>0)
		 {
                   Comparison= 0;
		 }
    }

  return Comparison;
}

void merge(Rows *arr, int leftHead, int Middle, int rightHead, int ColumnIndex)
{
  int i, j, k;
  int LeftTempSize = Middle - leftHead + 1;
  int RightTempSize =  rightHead - Middle;
  /* create temp arrays */
  Row *LeftTempArray[LeftTempSize], *RightTempArray[RightTempSize];
  /* Copy data to temp arrays L[] and R[] */
  for (i = 0; i < LeftTempSize; i++)
    LeftTempArray[i] = arr->arr[leftHead + i];
  for (j = 0; j <RightTempSize; j++)
    RightTempArray[j] = arr->arr[Middle + 1+ j];
  /* Merge the temp arrays back into arr[l..r]*/
  i = 0; // Initial index of first subarray
  j = 0; // Initial index of second subarray
  k = leftHead; // Initial index of merged subarray
  while (i <LeftTempSize  && j < RightTempSize)
    {
      //      printf("Comparing %s and %s\n", LeftTempArray[i]->cols->arr[ColumnIndex], RightTempArray[j]->cols->arr[ColumnIndex]);
      if (Compare(LeftTempArray[i]->cols->arr[ColumnIndex], RightTempArray[j]->cols->arr[ColumnIndex]))
        {
	  arr->arr[k] = LeftTempArray[i];
	  i++;
        }
      else
        {
	  arr->arr[k] = RightTempArray[j];
	  j++;
        }
      k++;
    }

  /* Copy the remaining elements of L[], if there
     are any */
  while (i < LeftTempSize)
    {
      arr->arr[k] = LeftTempArray[i];
      i++;
      k++;
    }

  /* Copy the remaining elements of R[], if there
     are any */
  while (j < RightTempSize)
    {
      arr->arr[k] = RightTempArray[j];
      j++;
      k++;
    }
}
/*
 */
void mergeSort(Rows *arr, int leftHead, int rightHead, int ColumnIndex)
{
  if (leftHead < rightHead)
    {
      // Same as (l+r)/2, but avoids overflow for
      // large l and h
      int Middle = leftHead+(rightHead-leftHead)/2;
      // Sort first and second halves
      //printf("Sorting %s\n", arr->arr[leftHead]->cols->arr[ColumnIndex]);
      mergeSort(arr, leftHead, Middle, ColumnIndex);
      mergeSort(arr, Middle+1, rightHead, ColumnIndex);
      merge(arr, leftHead, Middle, rightHead, ColumnIndex);
    }
}

