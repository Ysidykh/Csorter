#ifndef SORTER_H
#define SORTER_H
struct cols_array { //contains all data fields in one row
	char **arr; //array of data field pointers
	int length;
};

typedef struct cols_array Cols;
struct row {
	char *buf;
	Cols *cols;
};
typedef struct row Row; //struct 'row' alias
struct rows_array {
	Row **arr; //array of pointers to pointers to rows
	int length; //number of elements in array arr
};
typedef struct rows_array Rows; //rows_array alias

//ROW FUNCTIONS

Cols *cols_create();
int Compare(char *, char *);
void merge(Rows *, int, int , int , int );
void mergeSort(Rows *, int , int , int );
int cols_append(Cols *, char *);
void cols_print(Cols* );
void cols_populate(Cols *, char *);
void cols_destroy(Cols *);
Row *row_create(char *);
void row_destroy(Row* );
void row_print(Row* );
int row_find_column(Row *, const char *);
Rows *rows_create();
void rows_destroy(Rows* );
int rows_append(Rows* , Row* );
void rows_print(Rows* );
void rows_print_csv(Rows *, Row *, FILE *);
#endif
