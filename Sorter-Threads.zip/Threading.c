#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include<pthread.h>
void Hello2()
{
printf("Hello, again!");
return;
}
 void* Hello(void* X)
{
//sleep(1);
printf("%s","Hello World!\n");
Hello2();
return;
}
int main(int argc, char** argv )
{
printf("Main started...\n");
void*(*fp)(void*);
fp = Hello;
printf("Still running...\n");
int x = 9;
int* d = &(x);
pthread_t myThread;
//Hello(NULL);
pthread_create(&myThread, NULL, Hello, NULL);
//pthread_join(myThread, NULL);
printf("Main finished...");
exit(0);
}