#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
int main(int argc, char** argv)
{
int value = getc(stderr);
char buff[512];
int i = 0;
for(i<512; value!=EOF;i++)
{
buff[i] =  value;
value  = getc(stderr);
}
printf("Data read from stdin: %s", buff);
exit(0);
}
